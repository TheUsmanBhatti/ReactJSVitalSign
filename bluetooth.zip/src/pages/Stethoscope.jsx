// App.js
import { JitsiMeeting } from "@jitsi/react-sdk";
import React, { useState, useEffect, useRef } from "react";

const App = () => {
  const [bluetoothOn, setBluetoothOn] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [availableDevices, setAvailableDevices] = useState([]);
  const [connectedDevice, setConnectedDevice] = useState(null);

  const [audioContext, setAudioContext] = useState(null);
  const [audioSource, setAudioSource] = useState(null);

  const [data, setData] = useState(null);

  useEffect(() => {
    initBluetooth();
  }, []);

  const initBluetooth = async () => {
    try {
      const bluetooth = navigator.bluetooth;
      if (!bluetooth) {
        console.error("Web Bluetooth API is not supported in this browser.");
        return;
      }

      // Check if Bluetooth is available
      const isBluetoothAvailable = await navigator.bluetooth.getAvailability();
      if (!isBluetoothAvailable) {
        console.warn("Bluetooth is not available on this device.");
        return;
      }

      // Listen for changes in Bluetooth adapter state
      navigator.bluetooth.addEventListener("availabilitychanged", (event) => {
        setBluetoothOn(event.target.value === "available");
      });

      // Check initial Bluetooth state
      setBluetoothOn(await navigator.bluetooth.getAvailability());
    } catch (error) {
      console.error("Error initializing Bluetooth:", error);
    }
  };

  const handleDataUpdate = (value) => {
    // const value = event.target.value;
    // setData(value);

    // You can process or parse the data as needed
    console.log("Received data:", new TextDecoder().decode(value));
  };

  const startScanning = async () => {
    setScanning(true);
    try {
      //   let result = BluetoothUUID.getService("device_information");
      //   console.log("ress ", result);
      const device = await navigator.bluetooth.requestDevice({
        optionalServices: ["14839ac4-7d7e-415c-9a42-167340cf2339"],
        acceptAllDevices: true,
      });
      console.log("- ", device);
      setConnectedDevice(device);

      // Establish a Bluetooth connection and get a BluetoothRemoteGATTServer instance
      const server = await device.gatt.connect();
      console.log("server ", server);

      // Use the appropriate service UUID for your stethoscope
      const service = await server.getPrimaryService(
        "14839ac4-7d7e-415c-9a42-167340cf2339"
      );
      console.log("service ", service);
      // Use the appropriate characteristic UUID for audio streaming
      const characteristic = await service.getCharacteristic(
        "ba04c4b2-892b-43be-b69c-5d13f2195392"
      );
      console.log("characteristic ", characteristic);
      // Subscribe to characteristic value changes to receive audio data

      // Read the initial data
      const initialValue = await characteristic.readValue();
      console.log("initialValue ", initialValue);
      handleDataUpdate(initialValue);

      // Subscribe to notifications for real-time updates
      await characteristic.startNotifications();
      characteristic.addEventListener(
        "characteristicvaluechanged",
        handleDataUpdate
      );
    } catch (error) {
      console.error("Error scanning for devices:", error);
    } finally {
      setScanning(false);
    }
  };

  const handleAudioData = (event) => {
    // Process the audio data received from the stethoscope
    const audioData = event.target.value.buffer;
    // Use the audio data as needed (e.g., play the audio)
  };

  return (
    <div>
      <h1>Stethoscope App</h1>
      <p>Bluetooth is {bluetoothOn ? "ON" : "OFF"}</p>
      <hr />

      {bluetoothOn && (
        <div>
          <button onClick={startScanning} disabled={scanning}>
            {scanning ? "Scanning..." : "Scan for Devices"}
          </button>

          {connectedDevice && (
            <div>
              <p>Connected to: {connectedDevice.name}</p>
              {/* Add sound listening and recording logic here */}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default App;

// -service uuid :   14839ac4-7d7e-415c-9a42-167340cf2339
// -characteristic   0734594a-a8e7-4b1a-a6b1-cd5243059a57
//                   ba04c4b2-892b-43be-b69c-5d13f2195392
//                   e06d5efb-4f4a-45c0-9eb1-371ae5a14ad4
//
